/*
Nama : Adi Irwan Aris Munandar
NIM : 201011400640
*/
#include <iostream>
using namespace std;
int main()
{
    int l,m,n;
    cout<<"Masukkan angka bintang: ";
    cin>>l;
    for (m=0; m<l; m++)
    {
        for (n=0; n<=m; n++)
        {
            cout<<"*";
        }
        cout<<endl;
    }
    return 0;
}

